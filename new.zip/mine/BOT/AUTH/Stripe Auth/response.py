import traceback
from FUNC.defs import *
from FUNC.usersdb_func import *

async def get_charge_resp(result, user_id, fullcc):
    try:
        if isinstance(result, dict) and 'success' in result:
            if result['success'] == False:
                error = result['data']['error']['message']
                if 'code' in error:
                    return "CCN ✅"
                else:
                    return "DECLINED ❌"
            else:
                return "APPROVED ✅"
    except Exception as e:
        status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
        response = str(e) + " ❌"
        hits = "NO"

        json = {
            "status": status,
            "response": response,
            "hits": hits,
            "fullz": fullcc,
        }
        return json